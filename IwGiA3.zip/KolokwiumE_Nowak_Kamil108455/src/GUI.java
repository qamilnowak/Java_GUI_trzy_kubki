import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
// #2 Tworz� klas� o dowolnej klasie kt�ra rozszerza klas� JFrame i implementuje interfejs ActionListener
public class GUI extends JFrame implements ActionListener {
// #5 Tworz� potrzebne zmienne/pola i panele
	JButton nowagra = new JButton("Nowa gra");
	JButton poj1 = new JButton("Pojemnik 1");
	JButton poj2 = new JButton("Pojemnik 2");
	JButton poj3 = new JButton("Pojemnik 3");
	JLabel etykietaWynik = new JLabel("Wygrane:");
	//JPanel dla przycisk�w z "kubkami" - w tej samej lini ustalam jego layout na siatke 1x3
	JPanel pojemniki = new JPanel(new GridLayout(1, 3));
	//JPanel dla etykiety wyniku i pola teksowego -  w tej samej linni ustalam jego layout na FlowLayout - wszystko b�dzie wycentrowane
	JPanel wynikowePole = new JPanel(new FlowLayout());
	//tworz� zmienn� kt�ra b�dzie przechowywa�a nasz wynik 
	int wylosowanyPojemnik;
	//Pole tekstowe wynik z pocz�tkowym wynikiem 0
	JTextField wynik = new JTextField("0");
	//licznik wygranych
	int liczbaWygranych = 0;
	//blokuje dalsz� gr� po wygranej/przegranej ta zmienna - zgadywac gdzie jest kulka tylko raz
	int ileProb = 0;

//Tworz� bezparametrowy konstruktor klasy
	GUI(){
		//dodaje pola tekstowe - Pojemniki do JPanelu
		pojemniki.add(poj1);
		pojemniki.add(poj2);
		pojemniki.add(poj3);
		//dodaje etykiet� i pole wynik do Layout'u wynikowe pole - razem nazywaj� si� teraz wynikowePole
		wynikowePole.add(etykietaWynik);
		wynikowePole.add(wynik);
		//Dodaje actionlistenery do guzik�w - Pojemnik�w - w tym momencie co� ju� mo�na z nimi zrobi� w meodzie action performed
		poj1.addActionListener(this);
		poj2.addActionListener(this);
		poj3.addActionListener(this);
		//ustawiam layout ca�ego GUI na BorderLayout na taki w kt�rym mo�na wybra� co gdzie si� znajduje
		setLayout(new BorderLayout());
		//ustalam rozmiar pola tekstowego wynik - by�o troch� za ma�e
		wynik.setPreferredSize(new Dimension(30, 20));
		//Guzik Nowa Gra dodaje do Layout'u - i ustawiam ich pozycje na p�nocna
		this.add(nowagra, BorderLayout.NORTH);
		//JPanel pojemniki dodaje do Border Layout'u - i ustawiam ich pozycje na �rodek
		this.add(pojemniki, BorderLayout.CENTER);
		//wynikowePole dodaje do Layout'u - i ustawiam ich pozycje na po�udniow�
		this.add(wynikowePole, BorderLayout.SOUTH);
		//dodaje actionlistener'a do przycisku NOWA GRA teraz mo�na ju� co� z nim zrobic w metodzie acction performed
		nowagra.addActionListener(this);
		//ustawiam tytu� oknas
		setTitle("Gra w 3 kubki");
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		//tworze obiekt kt�ry bedzie zbiera� informacje jaki guzk zosta� naci�ni�ty
		Object zrodlo = e.getSource();
		//je�eli wci�ni�ty zostanie guzik NOWA GRA
		if(zrodlo == nowagra){
			//Losuje pojemnik Math flor zaokr�gla wynik - nie ma przecie� 1,375 kubka, losujemy od 1 do 3 dlatego wynik Math random mno�ymy razy 3 i dodajemy 1 �eby otrzymac po��dany przedzia�
			wylosowanyPojemnik = (int) Math.floor(Math.random()*3+1);
			//zmieniam tekst na Pojemnikach - mamy to drugi raz w programie aby gdy zrestartujemy gr� - nie by�o widac gdzie jest kulka
			poj1.setText("Pojemnik 1");
			poj2.setText("Pojemnik 2");
			poj3.setText("Pojemnik 3");
			//test losowo�ci pojemnika
			//	System.out.println(wylosowanyPojemnik);
			//zeruje licznik prob
			ileProb = 0;
		}

		//sprawdzamy czy nic nie zosta�o klikniete - je�eli nie (czyli ilo�� pr�b jest r�wna 0)po kolei sprawdzamy kt�ry guzik zostanie wci�ni�ty przez u�ytkownika
		if (ileProb ==0){
			//Pierwszy pojemnik
			if(zrodlo == poj1){
				//je�eli zosta� wcisni�ty pierwszy guzik blokujemy mo�liwo�� wciskania kolejnych
				ileProb+=1;
				//je�eli w klikni�tym pojemniku jest kulka  
				if (wylosowanyPojemnik == 1){
					// w tym miejscu dostajemy punkt
					liczbaWygranych+=1;
					//w tym miejscu wy�wietla sie on w polu tekstowym
					wynik.setText(Integer.toString(liczbaWygranych));
					//w tym miejscu wy�wietla sie napis na kubku
					poj1.setText("Tak");
				}else{
					//w tym miejscu wy�wietla sie napis na kubku
					poj1.setText("Nie");
				}
				//je�eli zosta� wcisni�ty drugi guzik blokujemy mo�liwo�� wciskania kolejnych
			}else if(zrodlo == poj2){
				ileProb+=1;
				if (wylosowanyPojemnik == 2){
					liczbaWygranych+=1;
					wynik.setText(Integer.toString(liczbaWygranych));
					poj2.setText("Tak");
				}else{
					poj2.setText("Nie");
					//	poj2.setBackground(Color.RED);
				}
				//je�eli zosta� wcisni�ty trzeci guzik blokujemy mo�liwo�� wciskania kolejnych
			}else if(zrodlo == poj3){
				ileProb+=1;
				if (wylosowanyPojemnik == 3){
					liczbaWygranych+=1;
					wynik.setText(Integer.toString(liczbaWygranych));
					poj3.setText("Tak");
				}else{
					poj3.setText("Nie");
				}
			}}

	}

}
