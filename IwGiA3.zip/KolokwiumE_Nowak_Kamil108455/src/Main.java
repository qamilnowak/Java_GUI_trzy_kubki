// #1 Tworz� klas� o oboj�tnie jakiej nazwie z metod� main
public class Main {
	public static void main(String[] args) {
		// #3 tworz� (chyba) obiekt klasy z kroku 2
		GUI mojeGUI = new GUI();
		// #4 dodaje niezb�dne parametry - po wykonaniu tego kroku po uruchomieniu programu powinni�my juz widzie� puste ale jenak ju� okienko
		//GUI jest widoczne dla u�ytkownika
		mojeGUI.setVisible(true);
		//ustalam rozmiar
		mojeGUI.setSize(450, 120);
		//wy�rodkowne okienko
		mojeGUI.setLocationRelativeTo(null);


	}
}
